<?php
require_once __DIR__ . '/google.php';

set_exception_handler(function ($e) {
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo json_encode([
        'ok' => false,
        'status' => 'error',
        'message' => 'خطأ في السيرفر: ' . $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
});

function ensure_account_columns(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $pdo = db();
    $cols = [];
    foreach ($pdo->query('SHOW COLUMNS FROM users') as $row) {
        $cols[$row['Field']] = true;
    }
    $alter = [];
    if (!isset($cols['password_hash'])) {
        $alter[] = 'ADD COLUMN password_hash VARCHAR(255) NULL';
    }
    if (!isset($cols['device_id'])) {
        $alter[] = 'ADD COLUMN device_id VARCHAR(64) NULL';
    }
    if (!isset($cols['api_token'])) {
        $alter[] = 'ADD COLUMN api_token VARCHAR(64) NULL';
    }
    if ($alter) {
        $pdo->exec('ALTER TABLE users ' . implode(', ', $alter));
    }
    $indexes = [];
    foreach ($pdo->query('SHOW INDEX FROM users') as $row) {
        $indexes[$row['Key_name']] = true;
    }
    if (!isset($indexes['uniq_users_device'])) {
        $pdo->exec('CREATE UNIQUE INDEX uniq_users_device ON users (device_id)');
    }
    if (!isset($indexes['uniq_users_token'])) {
        $pdo->exec('CREATE UNIQUE INDEX uniq_users_token ON users (api_token)');
    }
    ensure_ops_schema();
    $done = true;
}

ensure_account_columns();

function new_api_token(): string
{
    return bin2hex(random_bytes(32));
}

function account_payload(array $user, string $lang = 'ar'): array
{
    $payload = user_payload($user, $lang);
    $payload['api_token'] = (string)($user['api_token'] ?? '');
    $payload['account_id'] = (string)$user['google_id'];
    return $payload;
}

function find_user_by_token(string $token, string $deviceId): array
{
    if ($token === '' || $deviceId === '') {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'بيانات ناقصة'], 400);
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE api_token = ? LIMIT 1');
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if (!$user) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'الجلسة غير صالحة. سجّل الدخول مرة أخرى'], 401);
    }
    if (($user['device_id'] ?? '') !== $deviceId) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'هذا الحساب مرتبط بجهاز آخر'], 403);
    }
    return refresh_user_status($user);
}
