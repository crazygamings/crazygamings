<?php
require_once __DIR__ . '/google.php';

function new_api_token(): string
{
    return bin2hex(random_bytes(32));
}

function account_payload(array $user): array
{
    $payload = user_payload($user);
    $payload['api_token'] = (string)($user['api_token'] ?? '');
    $payload['account_id'] = (string)$user['google_id'];
    return $payload;
}

function find_user_by_token(string $token, string $deviceId): array
{
    if ($token === '' || $deviceId === '') {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'بيانات ناقصة'], 400);
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE api_token = ? LIMIT 1');
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if (!$user) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'الجلسة غير صالحة. سجّل الدخول مرة أخرى'], 401);
    }
    if (($user['device_id'] ?? '') !== $deviceId) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'هذا الحساب مرتبط بجهاز آخر'], 403);
    }
    return refresh_user_status($user);
}
