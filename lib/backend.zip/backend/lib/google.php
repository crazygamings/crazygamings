<?php

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/http.php';

/**
 * يتحقق من id_token عبر Google tokeninfo.
 * للإنتاج الأفضل استخدام مكتبة رسمية؛ هذا كافٍ للبداية.
 */
function verify_google_id_token(string $idToken): array
{
    $config = app_config();
    $url = 'https://oauth2.googleapis.com/tokeninfo?id_token=' . urlencode($idToken);
    $json = @file_get_contents($url);
    if ($json === false) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'تعذر التحقق من Google'], 502);
    }
    $data = json_decode($json, true);
    if (!is_array($data) || empty($data['sub'])) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'رمز Google غير صالح'], 401);
    }
    $aud = $data['aud'] ?? '';
    if ($aud !== $config['google_client_id']) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'client_id غير متطابق'], 401);
    }
    return [
        'google_id' => (string)$data['sub'],
        'email' => (string)($data['email'] ?? ''),
        'name' => (string)($data['name'] ?? ''),
    ];
}

function payment_methods_payload(): array
{
    $stmt = db()->query('SELECT method_key AS id, title, details FROM payment_methods WHERE is_active = 1 ORDER BY sort_order, id');
    return $stmt->fetchAll() ?: [];
}

function user_payload(array $user): array
{
    $expiresMs = 0;
    if (!empty($user['expires_at'])) {
        $expiresMs = strtotime($user['expires_at']) * 1000;
    }
    return [
        'ok' => true,
        'status' => $user['status'],
        'expires_at' => $expiresMs,
        'message' => status_message($user['status']),
        'payment_methods' => payment_methods_payload(),
    ];
}

function status_message(string $status): string
{
    switch ($status) {
        case 'trial':
            return 'أنت في الفترة التجريبية';
        case 'active':
            return 'اشتراكك مفعّل';
        case 'locked':
        case 'expired':
            return 'انتهت التجربة أو الاشتراك. أرسل إثبات الدفع للتفعيل';
        default:
            return $status;
    }
}

function refresh_user_status(array $user): array
{
    $trialDays = (int)setting('trial_days', '2');
    $now = time();
    $status = $user['status'];

    if ($status === 'active') {
        if (!empty($user['expires_at']) && strtotime($user['expires_at']) < $now) {
            $stmt = db()->prepare("UPDATE users SET status = 'expired' WHERE id = ?");
            $stmt->execute([$user['id']]);
            $user['status'] = 'expired';
        }
        return $user;
    }

    if ($status === 'trial') {
        $start = strtotime($user['trial_started_at']);
        $end = $start + ($trialDays * 86400);
        if ($now >= $end) {
            $stmt = db()->prepare("UPDATE users SET status = 'locked', expires_at = FROM_UNIXTIME(?) WHERE id = ?");
            $stmt->execute([$end, $user['id']]);
            $user['status'] = 'locked';
            $user['expires_at'] = date('Y-m-d H:i:s', $end);
        } else {
            $user['expires_at'] = date('Y-m-d H:i:s', $end);
        }
    }

    return $user;
}
