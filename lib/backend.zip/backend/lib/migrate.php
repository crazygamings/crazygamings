<?php
require_once __DIR__ . '/db.php';

function ensure_ops_schema(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $pdo = db();
    $cols = [];
    foreach ($pdo->query('SHOW COLUMNS FROM users') as $row) {
        $cols[$row['Field']] = true;
    }
    if (!isset($cols['banned'])) {
        $pdo->exec('ALTER TABLE users ADD COLUMN banned TINYINT(1) NOT NULL DEFAULT 0');
    }

    $pay = [];
    foreach ($pdo->query('SHOW COLUMNS FROM payment_requests') as $row) {
        $pay[$row['Field']] = true;
    }
    $alter = [];
    if (!isset($pay['amount'])) {
        $alter[] = 'ADD COLUMN amount DECIMAL(10,2) NULL';
    }
    if (!isset($pay['plan_key'])) {
        $alter[] = 'ADD COLUMN plan_key VARCHAR(32) NULL';
    }
    if (!isset($pay['receipt_name'])) {
        $alter[] = 'ADD COLUMN receipt_name VARCHAR(191) NULL';
    }
    if (!isset($pay['receipt_blob'])) {
        $alter[] = 'ADD COLUMN receipt_blob LONGBLOB NULL';
    }
    if ($alter) {
        $pdo->exec('ALTER TABLE payment_requests ' . implode(', ', $alter));
    }

    $pdo->exec(
        'CREATE TABLE IF NOT EXISTS notices (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            message VARCHAR(500) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            seen_at DATETIME NULL,
            INDEX (user_id, seen_at),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )'
    );
    $done = true;
}

function push_notice(PDO $pdo, int $userId, string $message): void
{
    $message = trim($message);
    if ($userId <= 0 || $message === '') {
        return;
    }
    if (function_exists('mb_substr')) {
        $message = mb_substr($message, 0, 500);
    } else {
        $message = substr($message, 0, 500);
    }
    $pdo->prepare('INSERT INTO notices (user_id, message) VALUES (?, ?)')->execute([$userId, $message]);
}

function attach_notice(array $payload, array $user): array
{
    if (empty($user['id'])) {
        return $payload;
    }
    $stmt = db()->prepare(
        'SELECT id, message FROM notices WHERE user_id = ? AND seen_at IS NULL ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute([(int)$user['id']]);
    $notice = $stmt->fetch();
    if ($notice) {
        $payload['notice_id'] = (int)$notice['id'];
        $payload['notice'] = (string)$notice['message'];
    }
    return $payload;
}
