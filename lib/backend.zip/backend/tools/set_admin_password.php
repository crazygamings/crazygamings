<?php
/**
 * تشغيل مرة واحدة من الطرفية:
 * php tools/set_admin_password.php admin NewStrongPassword
 */
require_once __DIR__ . '/../lib/db.php';

$username = $argv[1] ?? 'admin';
$password = $argv[2] ?? null;
if ($password === null || strlen($password) < 6) {
    fwrite(STDERR, "Usage: php set_admin_password.php <username> <password>\n");
    exit(1);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = db()->prepare(
    'INSERT INTO admins (username, password_hash) VALUES (?, ?)
     ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash)'
);
$stmt->execute([$username, $hash]);
echo "Password updated for {$username}\n";
