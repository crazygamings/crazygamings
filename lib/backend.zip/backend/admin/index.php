<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../lib/migrate.php';
require_admin();
ensure_ops_schema();

$pdo = db();
$q = trim($_GET['q'] ?? '');
$sql = 'SELECT u.*, (
            SELECT COALESCE(SUM(amount), 0) FROM payment_requests pr
            WHERE pr.user_id = u.id AND pr.status = \'approved\'
        ) AS paid_total
        FROM users u';
$params = [];
if ($q !== '') {
    $sql .= ' WHERE u.email LIKE ? OR u.display_name LIKE ? OR u.google_id LIKE ?';
    $like = '%' . $q . '%';
    $params = [$like, $like, $like];
}
$sql .= ' ORDER BY u.updated_at DESC LIMIT 200';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$counts = $pdo->query(
    "SELECT
        COUNT(*) AS total_users,
        SUM(status = 'active' AND banned = 0 AND expires_at > NOW()) AS active_users,
        SUM(status = 'trial' AND banned = 0 AND expires_at > NOW()) AS trial_users
     FROM users"
)->fetch();
$totalUsers = (int)($counts['total_users'] ?? 0);
$activeUsers = (int)($counts['active_users'] ?? 0);
$trialUsers = (int)($counts['trial_users'] ?? 0);
$inactiveUsers = max(0, $totalUsers - $activeUsers - $trialUsers);

$paid = $pdo->query(
    "SELECT COALESCE(SUM(amount), 0) AS total_amount, COUNT(*) AS paid_count
     FROM payment_requests WHERE status = 'approved'"
)->fetch();
$paidAmount = (float)($paid['total_amount'] ?? 0);
$paidCount = (int)($paid['paid_count'] ?? 0);

$pending = $pdo->query(
    "SELECT pr.*, u.email, u.display_name, pm.title AS method_title
     FROM payment_requests pr
     JOIN users u ON u.id = pr.user_id
     LEFT JOIN payment_methods pm ON pm.id = pr.method_id
     WHERE pr.status = 'pending'
     ORDER BY pr.created_at DESC
     LIMIT 100"
)->fetchAll();

function plan_label(string $plan): string
{
    if ($plan === 'quarter') {
        return '3 أشهر / 6 JD';
    }
    if ($plan === 'month') {
        return 'شهر / 2 JD';
    }
    return $plan !== '' ? $plan : '-';
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>لوحة الأدمن — Speed Click</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
  <header class="top">
    <strong>Speed Click Admin</strong>
    <nav>
      <a href="methods.php">وسائل الدفع</a>
      <a href="logout.php">خروج</a>
    </nav>
  </header>

  <main class="wrap">
    <section class="stats">
      <article class="stat">
        <span>مجموع المبالغ المدفوعة</span>
        <b><?= number_format($paidAmount, 2) ?> JD</b>
        <small><?= $paidCount ?> عملية مقبولة</small>
      </article>
      <article class="stat">
        <span>المستخدمون الفعالون</span>
        <b><?= $activeUsers ?></b>
        <small>اشتراك ساري</small>
      </article>
      <article class="stat">
        <span>غير الفعالين</span>
        <b><?= $inactiveUsers ?></b>
        <small>منتهٍ أو موقوف أو مقفل</small>
      </article>
      <article class="stat">
        <span>في التجربة</span>
        <b><?= $trialUsers ?></b>
        <small>من أصل <?= $totalUsers ?> حساب</small>
      </article>
    </section>

    <section class="card">
      <h2>طلبات الدفع المعلقة</h2>
      <p class="muted">يُقبل طلب واحد فقط كل 24 ساعة لكل حساب.</p>
      <?php if (!$pending): ?>
        <p class="muted">لا توجد طلبات حالياً.</p>
      <?php else: ?>
        <table>
          <thead>
            <tr>
              <th>المستخدم</th>
              <th>الباقة</th>
              <th>الوسيلة</th>
              <th>المرجع</th>
              <th>الإثبات</th>
              <th>إجراء</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($pending as $p): ?>
            <tr>
              <td><?= htmlspecialchars($p['display_name'] ?: $p['email']) ?><br><small><?= htmlspecialchars($p['email']) ?></small></td>
              <td><?= htmlspecialchars(plan_label((string)($p['plan_key'] ?? ''))) ?><br><small><?= htmlspecialchars((string)($p['amount'] ?? '')) ?> JD</small></td>
              <td><?= htmlspecialchars($p['method_title'] ?? '-') ?></td>
              <td><?= htmlspecialchars($p['reference_code']) ?></td>
              <td>
                <?php if (!empty($p['receipt_name'])): ?>
                  <a href="receipt.php?id=<?= (int)$p['id'] ?>" target="_blank">عرض الصورة</a>
                <?php else: ?>
                  -
                <?php endif; ?>
              </td>
              <td>
                <form method="post" action="activate.php" class="inline">
                  <input type="hidden" name="request_id" value="<?= (int)$p['id'] ?>">
                  <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                  <input type="number" name="days" value="<?= ($p['plan_key'] ?? '') === 'quarter' ? 90 : 30 ?>" min="1" max="3650">
                  <button name="action" value="approve">تفعيل</button>
                  <button name="action" value="reject" class="danger">رفض</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </section>

    <section class="card">
      <h2>المستخدمون</h2>
      <form method="get" class="search">
        <input name="q" value="<?= htmlspecialchars($q) ?>" placeholder="بحث بالبريد أو الاسم">
        <button type="submit">بحث</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>المستخدم</th>
            <th>الحالة</th>
            <th>ينتهي</th>
            <th>مدفوع</th>
            <th>تحكم</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td>
              <?= htmlspecialchars($u['display_name'] ?: '-') ?><br>
              <small><?= htmlspecialchars($u['email']) ?></small>
            </td>
            <td>
              <span class="badge <?= !empty($u['banned']) ? 'banned' : htmlspecialchars($u['status']) ?>">
                <?= !empty($u['banned']) ? 'banned' : htmlspecialchars($u['status']) ?>
              </span>
            </td>
            <td><?= htmlspecialchars($u['expires_at'] ?? '-') ?></td>
            <td><?= number_format((float)$u['paid_total'], 2) ?> JD</td>
            <td class="user-actions">
              <form method="post" action="activate.php" class="inline">
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <input type="number" name="days" value="30" min="1" max="3650">
                <button name="action" value="add_days">إضافة أيام</button>
                <button name="action" value="sub_days" class="warn">خصم أيام</button>
                <button name="action" value="kick" class="danger">طرد</button>
                <?php if (!empty($u['banned'])): ?>
                  <button name="action" value="unban">رفع الإيقاف</button>
                <?php endif; ?>
              </form>
              <form method="post" action="activate.php" class="inline">
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <input name="notice" maxlength="500" placeholder="تنبيه يصل داخل التطبيق">
                <button name="action" value="notify">إرسال</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </section>
  </main>
</body>
</html>
