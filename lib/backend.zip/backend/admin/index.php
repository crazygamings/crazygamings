<?php
require_once __DIR__ . '/_auth.php';
require_admin();

$pdo = db();
$q = trim($_GET['q'] ?? '');
$sql = 'SELECT * FROM users';
$params = [];
if ($q !== '') {
    $sql .= ' WHERE email LIKE ? OR display_name LIKE ? OR google_id LIKE ?';
    $like = '%' . $q . '%';
    $params = [$like, $like, $like];
}
$sql .= ' ORDER BY updated_at DESC LIMIT 200';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$pending = $pdo->query(
    "SELECT pr.*, u.email, u.display_name, pm.title AS method_title
     FROM payment_requests pr
     JOIN users u ON u.id = pr.user_id
     LEFT JOIN payment_methods pm ON pm.id = pr.method_id
     WHERE pr.status = 'pending'
     ORDER BY pr.created_at DESC
     LIMIT 100"
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>لوحة الأدمن — Speed Click</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
  <header class="top">
    <strong>Speed Click Admin</strong>
    <nav>
      <a href="methods.php">وسائل الدفع</a>
      <a href="logout.php">خروج</a>
    </nav>
  </header>

  <main class="wrap">
    <section class="card">
      <h2>طلبات الدفع المعلقة</h2>
      <?php if (!$pending): ?>
        <p class="muted">لا توجد طلبات حالياً.</p>
      <?php else: ?>
        <table>
          <thead>
            <tr>
              <th>المستخدم</th>
              <th>الوسيلة</th>
              <th>المرجع</th>
              <th>ملاحظة</th>
              <th>إجراء</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($pending as $p): ?>
            <tr>
              <td><?= htmlspecialchars($p['display_name'] ?: $p['email']) ?><br><small><?= htmlspecialchars($p['email']) ?></small></td>
              <td><?= htmlspecialchars($p['method_title'] ?? '-') ?></td>
              <td><?= htmlspecialchars($p['reference_code']) ?></td>
              <td><?= htmlspecialchars($p['note'] ?? '') ?></td>
              <td>
                <form method="post" action="activate.php" class="inline">
                  <input type="hidden" name="request_id" value="<?= (int)$p['id'] ?>">
                  <input type="hidden" name="user_id" value="<?= (int)$p['user_id'] ?>">
                  <input type="number" name="days" value="30" min="1" max="365" title="أيام التفعيل">
                  <button name="action" value="approve">تفعيل</button>
                  <button name="action" value="reject" class="danger">رفض</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </section>

    <section class="card">
      <h2>المستخدمون</h2>
      <form method="get" class="search">
        <input name="q" value="<?= htmlspecialchars($q) ?>" placeholder="بحث بالبريد أو الاسم">
        <button type="submit">بحث</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>المستخدم</th>
            <th>الحالة</th>
            <th>ينتهي</th>
            <th>تفعيل يدوي</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td>
              <?= htmlspecialchars($u['display_name'] ?: '-') ?><br>
              <small><?= htmlspecialchars($u['email']) ?></small>
            </td>
            <td><span class="badge <?= htmlspecialchars($u['status']) ?>"><?= htmlspecialchars($u['status']) ?></span></td>
            <td><?= htmlspecialchars($u['expires_at'] ?? '-') ?></td>
            <td>
              <form method="post" action="activate.php" class="inline">
                <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                <input type="number" name="days" value="30" min="1" max="365">
                <button name="action" value="activate_user">تفعيل</button>
                <button name="action" value="lock_user" class="danger">قفل</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </section>
  </main>
</body>
</html>
