<?php
require_once __DIR__ . '/_auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$action = $_POST['action'] ?? '';
$userId = (int)($_POST['user_id'] ?? 0);
$days = max(1, min(365, (int)($_POST['days'] ?? setting('default_active_days', '30'))));
$requestId = (int)($_POST['request_id'] ?? 0);
$pdo = db();

if ($action === 'approve' && $userId > 0) {
    $expires = date('Y-m-d H:i:s', time() + $days * 86400);
    $pdo->prepare("UPDATE users SET status = 'active', expires_at = ? WHERE id = ?")
        ->execute([$expires, $userId]);
    if ($requestId > 0) {
        $pdo->prepare("UPDATE payment_requests SET status = 'approved', reviewed_at = NOW() WHERE id = ?")
            ->execute([$requestId]);
    }
}

if ($action === 'reject' && $requestId > 0) {
    $pdo->prepare("UPDATE payment_requests SET status = 'rejected', reviewed_at = NOW() WHERE id = ?")
        ->execute([$requestId]);
}

if ($action === 'activate_user' && $userId > 0) {
    $expires = date('Y-m-d H:i:s', time() + $days * 86400);
    $pdo->prepare("UPDATE users SET status = 'active', expires_at = ? WHERE id = ?")
        ->execute([$expires, $userId]);
}

if ($action === 'lock_user' && $userId > 0) {
    $pdo->prepare("UPDATE users SET status = 'locked' WHERE id = ?")->execute([$userId]);
}

header('Location: index.php');
exit;
