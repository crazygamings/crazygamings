<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../lib/migrate.php';
require_admin();
ensure_ops_schema();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$action = (string)($_POST['action'] ?? '');
$userId = (int)($_POST['user_id'] ?? 0);
$days = max(1, min(3650, (int)($_POST['days'] ?? setting('default_active_days', '30'))));
$requestId = (int)($_POST['request_id'] ?? 0);
$notice = trim((string)($_POST['notice'] ?? ''));
$pdo = db();

if ($action === 'approve' && $userId > 0) {
    $expires = date('Y-m-d H:i:s', time() + $days * 86400);
    $pdo->prepare("UPDATE users SET status = 'active', banned = 0, expires_at = ? WHERE id = ?")
        ->execute([$expires, $userId]);
    if ($requestId > 0) {
        $pdo->prepare("UPDATE payment_requests SET status = 'approved', reviewed_at = NOW() WHERE id = ?")
            ->execute([$requestId]);
    }
    push_notice($pdo, $userId, 'تم تفعيل اشتراكك لمدة ' . $days . ' يوم');
}

if ($action === 'reject' && $requestId > 0) {
    $pdo->prepare("UPDATE payment_requests SET status = 'rejected', reviewed_at = NOW() WHERE id = ?")
        ->execute([$requestId]);
    if ($userId > 0) {
        push_notice($pdo, $userId, 'تم رفض طلب الدفع. تحقق من البيانات وأعد الإرسال بعد 24 ساعة');
    }
}

if ($action === 'activate_user' && $userId > 0) {
    $expires = date('Y-m-d H:i:s', time() + $days * 86400);
    $pdo->prepare("UPDATE users SET status = 'active', banned = 0, expires_at = ? WHERE id = ?")
        ->execute([$expires, $userId]);
    push_notice($pdo, $userId, 'تم تفعيل اشتراكك لمدة ' . $days . ' يوم');
}

if ($action === 'add_days' && $userId > 0) {
    $user = user_row($pdo, $userId);
    $base = strtotime((string)($user['expires_at'] ?? '')) ?: time();
    if ($base < time()) {
        $base = time();
    }
    $expires = date('Y-m-d H:i:s', $base + $days * 86400);
    $pdo->prepare("UPDATE users SET status = 'active', banned = 0, expires_at = ? WHERE id = ?")
        ->execute([$expires, $userId]);
    push_notice($pdo, $userId, 'تمت إضافة ' . $days . ' يوم إلى اشتراكك');
}

if ($action === 'sub_days' && $userId > 0) {
    $user = user_row($pdo, $userId);
    $base = strtotime((string)($user['expires_at'] ?? '')) ?: time();
    $newTs = $base - $days * 86400;
    if ($newTs <= time()) {
        $pdo->prepare("UPDATE users SET status = 'locked', expires_at = NOW() WHERE id = ?")
            ->execute([$userId]);
        push_notice($pdo, $userId, 'تم خصم الأيام المتبقية وانتهى الاشتراك');
    } else {
        $expires = date('Y-m-d H:i:s', $newTs);
        $pdo->prepare("UPDATE users SET status = 'active', expires_at = ? WHERE id = ?")
            ->execute([$expires, $userId]);
        push_notice($pdo, $userId, 'تم خصم ' . $days . ' يوم من اشتراكك');
    }
}

if ($action === 'kick' && $userId > 0) {
    $pdo->prepare("UPDATE users SET status = 'locked', banned = 1, expires_at = NOW() WHERE id = ?")
        ->execute([$userId]);
    push_notice($pdo, $userId, 'تم إيقاف حسابك من الإدارة');
}

if ($action === 'unban' && $userId > 0) {
    $pdo->prepare('UPDATE users SET banned = 0 WHERE id = ?')->execute([$userId]);
    push_notice($pdo, $userId, 'تم رفع الإيقاف عن الحساب');
}

if ($action === 'lock_user' && $userId > 0) {
    $pdo->prepare("UPDATE users SET status = 'locked', expires_at = NOW() WHERE id = ?")->execute([$userId]);
    push_notice($pdo, $userId, 'تم إيقاف الاشتراك');
}

if ($action === 'notify' && $userId > 0) {
    push_notice($pdo, $userId, $notice);
}

header('Location: index.php');
exit;

function user_row(PDO $pdo, int $userId): array
{
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    return $user ?: [];
}
