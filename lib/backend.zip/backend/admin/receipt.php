<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../lib/migrate.php';
require_admin();
ensure_ops_schema();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare('SELECT receipt_name, receipt_blob FROM payment_requests WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$row = $stmt->fetch();
$blob = $row['receipt_blob'] ?? '';
if ($blob === '' || $blob === null) {
    http_response_code(404);
    echo 'Not found';
    exit;
}
$name = (string)($row['receipt_name'] ?? 'receipt.jpg');
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
$types = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
header('X-Content-Type-Options: nosniff');
echo $blob;
