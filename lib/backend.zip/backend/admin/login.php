<?php
require_once __DIR__ . '/_auth.php';

if (admin_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = (string)($_POST['password'] ?? '');
    if (attempt_login($user, $pass)) {
        header('Location: index.php');
        exit;
    }
    $error = 'بيانات الدخول غير صحيحة';
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>دخول الأدمن — Speed Click</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body class="auth">
  <form method="post" class="card">
    <h1>Speed Click</h1>
    <p>لوحة تفعيل الاشتراكات</p>
    <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <label>اسم المستخدم</label>
    <input name="username" required autofocus>
    <label>كلمة المرور</label>
    <input type="password" name="password" required>
    <button type="submit">دخول</button>
  </form>
</body>
</html>
