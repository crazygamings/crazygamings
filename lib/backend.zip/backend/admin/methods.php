<?php
require_once __DIR__ . '/_auth.php';
require_admin();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $details = trim($_POST['details'] ?? '');
    $active = isset($_POST['is_active']) ? 1 : 0;
    if ($id > 0 && $title !== '') {
        $pdo->prepare('UPDATE payment_methods SET title = ?, details = ?, is_active = ? WHERE id = ?')
            ->execute([$title, $details, $active, $id]);
    }
    header('Location: methods.php');
    exit;
}

$methods = $pdo->query('SELECT * FROM payment_methods ORDER BY sort_order, id')->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>وسائل الدفع</title>
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
  <header class="top">
    <strong>وسائل الدفع المحلية</strong>
    <nav><a href="index.php">رجوع</a></nav>
  </header>
  <main class="wrap">
    <?php foreach ($methods as $m): ?>
      <form method="post" class="card">
        <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
        <label>العنوان</label>
        <input name="title" value="<?= htmlspecialchars($m['title']) ?>" required>
        <label>التفاصيل (تظهر للمستخدم)</label>
        <textarea name="details" rows="4" required><?= htmlspecialchars($m['details']) ?></textarea>
        <label><input type="checkbox" name="is_active" <?= $m['is_active'] ? 'checked' : '' ?>"> مفعّلة</label>
        <button type="submit">حفظ</button>
      </form>
    <?php endforeach; ?>
  </main>
</body>
</html>
