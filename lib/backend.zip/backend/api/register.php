<?php
require_once __DIR__ . '/../lib/account.php';

require_post();
$body = read_json_body();
$name = trim((string)($body['name'] ?? ''));
$email = strtolower(trim((string)($body['email'] ?? '')));
$password = (string)($body['password'] ?? '');
$deviceId = trim((string)($body['device_id'] ?? ''));

if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6 || strlen($deviceId) < 8) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'أدخل الاسم والبريد وكلمة مرور من 6 أحرف'], 400);
}

$pdo = db();
$byDevice = $pdo->prepare('SELECT id FROM users WHERE device_id = ? LIMIT 1');
$byDevice->execute([$deviceId]);
if ($byDevice->fetch()) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'هذا الجهاز لديه حساب بالفعل. سجّل الدخول به'], 409);
}

$byEmail = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
$byEmail->execute([$email]);
if ($byEmail->fetch()) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'هذا البريد مسجّل مسبقاً'], 409);
}

$trialDays = (int)setting('trial_days', '2');
$trialEnd = date('Y-m-d H:i:s', time() + $trialDays * 86400);
$token = new_api_token();
$googleId = 'dev_' . $deviceId;

$ins = $pdo->prepare(
    'INSERT INTO users (google_id, email, display_name, password_hash, device_id, api_token, status, trial_started_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, \'trial\', NOW(), ?)'
);
$ins->execute([
    $googleId,
    $email,
    $name,
    password_hash($password, PASSWORD_DEFAULT),
    $deviceId,
    $token,
    $trialEnd,
]);

$stmt = $pdo->prepare('SELECT * FROM users WHERE google_id = ? LIMIT 1');
$stmt->execute([$googleId]);
$user = refresh_user_status($stmt->fetch());
json_response(account_payload($user, request_lang($body)));
