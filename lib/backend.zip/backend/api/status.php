<?php
require_once __DIR__ . '/../lib/google.php';

require_post();
$body = read_json_body();
$idToken = trim((string)($body['id_token'] ?? ''));
$googleId = trim((string)($body['google_id'] ?? ''));

if ($idToken === '' || $googleId === '') {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'بيانات ناقصة'], 400);
}

$google = verify_google_id_token($idToken);
if ($google['google_id'] !== $googleId) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'google_id غير متطابق'], 401);
}

$stmt = db()->prepare('SELECT * FROM users WHERE google_id = ? LIMIT 1');
$stmt->execute([$googleId]);
$user = $stmt->fetch();
if (!$user) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'المستخدم غير موجود'], 404);
}

$user = refresh_user_status($user);
json_response(user_payload($user));
