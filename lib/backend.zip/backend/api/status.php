<?php
require_once __DIR__ . '/../lib/account.php';

require_post();
$body = read_json_body();
if (trim((string)($body['api_token'] ?? '')) !== '') {
    $user = find_user_by_token(
        trim((string)$body['api_token']),
        trim((string)($body['device_id'] ?? ''))
    );
    json_response(account_payload($user));
}

$idToken = trim((string)($body['id_token'] ?? ''));
$googleId = trim((string)($body['google_id'] ?? ''));

if ($idToken === '' || $googleId === '') {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'بيانات ناقصة'], 400);
}

$google = verify_google_id_token($idToken);
if ($google['google_id'] !== $googleId) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'google_id غير متطابق'], 401);
}

$stmt = db()->prepare('SELECT * FROM users WHERE google_id = ? LIMIT 1');
$stmt->execute([$googleId]);
$user = $stmt->fetch();
if (!$user) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'المستخدم غير موجود'], 404);
}

$user = refresh_user_status($user);
json_response(user_payload($user));
