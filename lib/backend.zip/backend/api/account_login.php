<?php
require_once __DIR__ . '/../lib/account.php';

require_post();
$body = read_json_body();
$email = strtolower(trim((string)($body['email'] ?? '')));
$password = (string)($body['password'] ?? '');
$deviceId = trim((string)($body['device_id'] ?? ''));

if ($email === '' || $password === '' || $deviceId === '') {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'أدخل البريد وكلمة المرور'], 400);
}

$stmt = db()->prepare('SELECT * FROM users WHERE email = ? AND password_hash IS NOT NULL LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();
if (!$user || !password_verify($password, (string)$user['password_hash'])) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'البريد أو كلمة المرور غير صحيحة'], 401);
}
if (($user['device_id'] ?? '') !== $deviceId) {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'هذا الحساب مرتبط بجهاز آخر'], 403);
}

$token = new_api_token();
db()->prepare('UPDATE users SET api_token = ? WHERE id = ?')->execute([$token, $user['id']]);
$user['api_token'] = $token;
$user = refresh_user_status($user);
json_response(account_payload($user, request_lang($body)));
