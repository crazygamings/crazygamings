<?php
require_once __DIR__ . '/../lib/google.php';

require_post();
$body = read_json_body();
$idToken = trim((string)($body['id_token'] ?? ''));
if ($idToken === '') {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'id_token مطلوب'], 400);
}

$google = verify_google_id_token($idToken);
$pdo = db();

$stmt = $pdo->prepare('SELECT * FROM users WHERE google_id = ? LIMIT 1');
$stmt->execute([$google['google_id']]);
$user = $stmt->fetch();

$trialDays = (int)setting('trial_days', '2');

if (!$user) {
    $trialEnd = date('Y-m-d H:i:s', time() + $trialDays * 86400);
    $ins = $pdo->prepare(
        'INSERT INTO users (google_id, email, display_name, status, trial_started_at, expires_at)
         VALUES (?, ?, ?, \'trial\', NOW(), ?)'
    );
    $ins->execute([
        $google['google_id'],
        $google['email'],
        $google['name'],
        $trialEnd,
    ]);
    $stmt->execute([$google['google_id']]);
    $user = $stmt->fetch();
} else {
    $upd = $pdo->prepare('UPDATE users SET email = ?, display_name = ? WHERE id = ?');
    $upd->execute([$google['email'], $google['name'], $user['id']]);
    $user['email'] = $google['email'];
    $user['display_name'] = $google['name'];
}

$user = refresh_user_status($user);
json_response(user_payload($user));
