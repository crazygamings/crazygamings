<?php
require_once __DIR__ . '/../lib/account.php';

require_post();
$contentType = (string)($_SERVER['CONTENT_TYPE'] ?? '');
$body = stripos($contentType, 'multipart/form-data') !== false ? $_POST : read_json_body();
$lang = request_lang($body);
$methodKey = trim((string)($body['method_id'] ?? ''));
$reference = trim((string)($body['reference'] ?? ''));
$note = trim((string)($body['note'] ?? ''));
$plan = trim((string)($body['plan'] ?? 'month'));
if ($plan !== 'quarter') {
    $plan = 'month';
}
$amount = $plan === 'quarter' ? 6.00 : 2.00;

if ($reference === '') {
    json_response([
        'ok' => false,
        'status' => 'error',
        'message' => t($lang, 'أدخل رقم مرجع الحوالة', 'Enter the transfer reference'),
    ], 400);
}

if (trim((string)($body['api_token'] ?? '')) !== '') {
    $user = find_user_by_token(
        trim((string)$body['api_token']),
        trim((string)($body['device_id'] ?? ''))
    );
} else {
    $idToken = trim((string)($body['id_token'] ?? ''));
    $googleId = trim((string)($body['google_id'] ?? ''));
    if ($idToken === '' || $googleId === '') {
        json_response([
            'ok' => false,
            'status' => 'error',
            'message' => t($lang, 'أكمل بيانات الدفع', 'Payment details are incomplete'),
        ], 400);
    }
    $google = verify_google_id_token($idToken);
    if ($google['google_id'] !== $googleId) {
        json_response(['ok' => false, 'status' => 'error', 'message' => t($lang, 'غير مصرح', 'Unauthorized')], 401);
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE google_id = ? LIMIT 1');
    $stmt->execute([$googleId]);
    $user = $stmt->fetch();
    if (!$user) {
        json_response(['ok' => false, 'status' => 'error', 'message' => t($lang, 'المستخدم غير موجود', 'User not found')], 404);
    }
}

if (!empty($user['banned'])) {
    json_response([
        'ok' => false,
        'status' => 'banned',
        'message' => t($lang, 'هذا الحساب موقوف. لا يمكن إرسال طلب دفع', 'This account is suspended'),
    ], 403);
}

$recent = db()->prepare(
    'SELECT created_at FROM payment_requests
     WHERE user_id = ? AND created_at >= (NOW() - INTERVAL 1 DAY)
     ORDER BY created_at DESC LIMIT 1'
);
$recent->execute([(int)$user['id']]);
if ($recent->fetch()) {
    json_response([
        'ok' => false,
        'status' => 'error',
        'message' => t(
            $lang,
            'يمكن إرسال طلب دفع واحد فقط كل 24 ساعة',
            'Only one payment request is allowed every 24 hours'
        ),
    ], 429);
}

$receipt = read_receipt_upload($lang);

$methodId = null;
if ($methodKey !== '') {
    $m = db()->prepare('SELECT id FROM payment_methods WHERE method_key = ? AND is_active = 1 LIMIT 1');
    $m->execute([$methodKey]);
    $row = $m->fetch();
    $methodId = $row ? (int)$row['id'] : null;
}

$ins = db()->prepare(
    'INSERT INTO payment_requests
        (user_id, method_id, reference_code, note, status, amount, plan_key, receipt_name, receipt_blob)
     VALUES (?, ?, ?, ?, \'pending\', ?, ?, ?, ?)'
);
$ins->execute([
    (int)$user['id'],
    $methodId,
    $reference,
    $note,
    $amount,
    $plan,
    $receipt['name'],
    $receipt['bytes'],
]);

json_response([
    'ok' => true,
    'status' => !empty($user['banned']) ? 'banned' : $user['status'],
    'expires_at' => !empty($user['expires_at']) ? strtotime($user['expires_at']) * 1000 : 0,
    'message' => t(
        $lang,
        'تم استلام طلب الدفع. سيتم التفعيل بعد مراجعة الأدمن.',
        'Payment request received. It will be activated after admin review.'
    ),
    'payment_methods' => payment_methods_payload(),
    'receipt_saved' => $receipt['name'] !== null,
]);

function read_receipt_upload(string $lang): array
{
    if (empty($_FILES['receipt']['tmp_name']) || !is_uploaded_file($_FILES['receipt']['tmp_name'])) {
        return ['name' => null, 'bytes' => null];
    }
    if ((int)$_FILES['receipt']['size'] > 4 * 1024 * 1024) {
        json_response([
            'ok' => false,
            'status' => 'error',
            'message' => t($lang, 'حجم الصورة أكبر من 4 ميغابايت', 'Image is larger than 4 MB'),
        ], 400);
    }
    $mime = '';
    if (function_exists('mime_content_type')) {
        $mime = (string)mime_content_type($_FILES['receipt']['tmp_name']);
    }
    $map = [
        'image/jpeg' => 'jpg',
        'image/jpg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];
    $ext = $map[$mime] ?? '';
    if ($ext === '') {
        $original = strtolower((string)($_FILES['receipt']['name'] ?? ''));
        if (substr($original, -4) === '.png') {
            $ext = 'png';
        } elseif (substr($original, -5) === '.webp') {
            $ext = 'webp';
        } elseif (substr($original, -4) === '.jpg' || substr($original, -5) === '.jpeg') {
            $ext = 'jpg';
        }
    }
    if ($ext === '') {
        json_response([
            'ok' => false,
            'status' => 'error',
            'message' => t($lang, 'الصورة يجب أن تكون JPG أو PNG', 'Image must be JPG or PNG'),
        ], 400);
    }
    $bytes = file_get_contents($_FILES['receipt']['tmp_name']);
    if ($bytes === false || $bytes === '') {
        json_response([
            'ok' => false,
            'status' => 'error',
            'message' => t($lang, 'تعذر قراءة الصورة', 'Could not read the image'),
        ], 400);
    }
    return ['name' => 'receipt.' . $ext, 'bytes' => $bytes];
}
