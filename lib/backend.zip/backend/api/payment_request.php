<?php
require_once __DIR__ . '/../lib/account.php';

require_post();
$body = read_json_body();
$methodKey = trim((string)($body['method_id'] ?? ''));
$reference = trim((string)($body['reference'] ?? ''));
$note = trim((string)($body['note'] ?? ''));

if ($reference === '') {
    json_response(['ok' => false, 'status' => 'error', 'message' => 'أكمل بيانات الدفع'], 400);
}

if (trim((string)($body['api_token'] ?? '')) !== '') {
    $user = find_user_by_token(
        trim((string)$body['api_token']),
        trim((string)($body['device_id'] ?? ''))
    );
} else {
    $idToken = trim((string)($body['id_token'] ?? ''));
    $googleId = trim((string)($body['google_id'] ?? ''));
    if ($idToken === '' || $googleId === '') {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'أكمل بيانات الدفع'], 400);
    }
    $google = verify_google_id_token($idToken);
    if ($google['google_id'] !== $googleId) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'غير مصرح'], 401);
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE google_id = ? LIMIT 1');
    $stmt->execute([$googleId]);
    $user = $stmt->fetch();
    if (!$user) {
        json_response(['ok' => false, 'status' => 'error', 'message' => 'المستخدم غير موجود'], 404);
    }
}

$methodId = null;
if ($methodKey !== '') {
    $m = db()->prepare('SELECT id FROM payment_methods WHERE method_key = ? AND is_active = 1 LIMIT 1');
    $m->execute([$methodKey]);
    $row = $m->fetch();
    $methodId = $row ? (int)$row['id'] : null;
}

$ins = db()->prepare(
    'INSERT INTO payment_requests (user_id, method_id, reference_code, note, status)
     VALUES (?, ?, ?, ?, \'pending\')'
);
$ins->execute([$user['id'], $methodId, $reference, $note]);

json_response([
    'ok' => true,
    'status' => $user['status'],
    'expires_at' => !empty($user['expires_at']) ? strtotime($user['expires_at']) * 1000 : 0,
    'message' => 'تم استلام طلب الدفع. سيتم التفعيل بعد مراجعة الأدمن.',
    'payment_methods' => payment_methods_payload(),
]);
