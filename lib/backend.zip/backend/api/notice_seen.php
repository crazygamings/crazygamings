<?php
require_once __DIR__ . '/../lib/account.php';

require_post();
$body = read_json_body();
$user = find_user_by_token(
    trim((string)($body['api_token'] ?? '')),
    trim((string)($body['device_id'] ?? ''))
);
$noticeId = (int)($body['notice_id'] ?? 0);
if ($noticeId > 0) {
    db()->prepare('UPDATE notices SET seen_at = NOW() WHERE id = ? AND user_id = ? AND seen_at IS NULL')
        ->execute([$noticeId, (int)$user['id']]);
}
json_response(['ok' => true, 'status' => 'ok', 'message' => '']);
