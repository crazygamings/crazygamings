USE speed_click;

ALTER TABLE users
  ADD COLUMN password_hash VARCHAR(255) NULL,
  ADD COLUMN device_id VARCHAR(64) NULL,
  ADD COLUMN api_token VARCHAR(64) NULL;

CREATE UNIQUE INDEX uniq_users_device ON users (device_id);
CREATE UNIQUE INDEX uniq_users_token ON users (api_token);
