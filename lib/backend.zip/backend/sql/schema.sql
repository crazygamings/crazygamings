CREATE DATABASE IF NOT EXISTS speed_click
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE speed_click;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  google_id VARCHAR(64) NOT NULL UNIQUE,
  email VARCHAR(191) NOT NULL,
  display_name VARCHAR(191) DEFAULT '',
  password_hash VARCHAR(255) NULL,
  device_id VARCHAR(64) NULL,
  api_token VARCHAR(64) NULL,
  status ENUM('trial','active','locked','expired') NOT NULL DEFAULT 'trial',
  banned TINYINT(1) NOT NULL DEFAULT 0,
  trial_started_at DATETIME NOT NULL,
  expires_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (status),
  INDEX (email)
);

CREATE TABLE IF NOT EXISTS payment_methods (
  id INT AUTO_INCREMENT PRIMARY KEY,
  method_key VARCHAR(64) NOT NULL UNIQUE,
  title VARCHAR(128) NOT NULL,
  details TEXT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS payment_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  method_id INT NULL,
  reference_code VARCHAR(191) NOT NULL,
  note TEXT,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  amount DECIMAL(10,2) NULL,
  plan_key VARCHAR(32) NULL,
  receipt_name VARCHAR(191) NULL,
  receipt_blob LONGBLOB NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (method_id) REFERENCES payment_methods(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS notices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  message VARCHAR(500) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  seen_at DATETIME NULL,
  INDEX (user_id, seen_at),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS settings (
  setting_key VARCHAR(64) PRIMARY KEY,
  setting_value VARCHAR(255) NOT NULL
);

INSERT INTO settings (setting_key, setting_value) VALUES
  ('trial_days', '2'),
  ('default_active_days', '30')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- أنشئ الأدمن عبر: php tools/set_admin_password.php admin YOUR_PASSWORD
-- (لا تعتمد على كلمة مرور افتراضية في الإنتاج)

INSERT INTO payment_methods (method_key, title, details, sort_order) VALUES
  ('cliq', 'CliQ', 'Abofaris', 1),
  ('orange', 'أورنج موني', '0777998949', 2)
ON DUPLICATE KEY UPDATE
  title = VALUES(title),
  details = VALUES(details),
  sort_order = VALUES(sort_order);
