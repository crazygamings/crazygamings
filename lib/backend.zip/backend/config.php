<?php
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'speed_click',
    'db_user' => 'speedclick',
    'db_pass' => 'Abdulla@000',
    'db_charset' => 'utf8mb4',

    'google_client_id' => '309759344150-qqs197dohtjs1975aro23dtc6h49f6gj.apps.googleusercontent.com',

    'admin_session_name' => 'speed_click_admin',

    'timezone' => 'Asia/Riyadh',
];
