<?php
/**
 * عدّل هذه القيم حسب استضافتك.
 */
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'speed_click',
    'db_user' => 'root',
    'db_pass' => '',
    'db_charset' => 'utf8mb4',

    // نفس Web Client ID المستخدم في تطبيق أندرويد
    'google_client_id' => 'YOUR_GOOGLE_WEB_CLIENT_ID.apps.googleusercontent.com',

    // اختياري: مفتاح بسيط لحماية الأدمن عبر HTTPS فقط
    'admin_session_name' => 'speed_click_admin',

    'timezone' => 'Asia/Riyadh',
];
